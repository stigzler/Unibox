﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Unibox.Data.Constants
{
    internal class Strings
    {
        public const string EncryptionRoot = @"wZ,![6Vhh6jr#}=naW5Nm{KO8~BXlo]8fa4T=a)^c=.j1~@[pe";
    }
}