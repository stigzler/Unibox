﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Unibox.Controls
{
    public partial class TouchComboBox : UserControl
    {
        // Dependency Properties for custom functionality
        public static readonly DependencyProperty MaxVisibleItemsProperty =
            DependencyProperty.Register("MaxVisibleItems", typeof(int), typeof(TouchComboBox), new PropertyMetadata(10));

        public static readonly DependencyProperty MaxHeightInPixelsProperty =
            DependencyProperty.Register("MaxHeightInPixels", typeof(double), typeof(TouchComboBox), new PropertyMetadata(double.NaN));

        public static readonly DependencyProperty ScrollAccelerationProperty =
            DependencyProperty.Register("ScrollAcceleration", typeof(double), typeof(TouchComboBox), new PropertyMetadata(0.1));

        public static readonly DependencyProperty ScrollDecelerationProperty =
            DependencyProperty.Register("ScrollDeceleration", typeof(double), typeof(TouchComboBox), new PropertyMetadata(0.2));

        public static readonly DependencyProperty IsDropDownOpenProperty =
            DependencyProperty.Register("IsDropDownOpen", typeof(bool), typeof(TouchComboBox), new PropertyMetadata(false));

        public static readonly DependencyProperty CalculatedMaxDropDownHeightProperty =
            DependencyProperty.Register("CalculatedMaxDropDownHeight", typeof(double), typeof(TouchComboBox), new PropertyMetadata(double.NaN));

        // ComboBox properties to expose
        public static readonly DependencyProperty ItemsSourceProperty =
            DependencyProperty.Register("ItemsSource", typeof(IEnumerable), typeof(TouchComboBox), new PropertyMetadata(null));

        public static readonly DependencyProperty SelectedItemProperty =
            DependencyProperty.Register("SelectedItem", typeof(object), typeof(TouchComboBox), new PropertyMetadata(null));

        public static readonly DependencyProperty DisplayMemberPathProperty =
            DependencyProperty.Register("DisplayMemberPath", typeof(string), typeof(TouchComboBox), new PropertyMetadata(string.Empty));

        public static readonly DependencyProperty SelectedValuePathProperty =
            DependencyProperty.Register("SelectedValuePath", typeof(string), typeof(TouchComboBox), new PropertyMetadata(string.Empty));

        public static readonly DependencyProperty SelectedValueProperty =
            DependencyProperty.Register("SelectedValue", typeof(object), typeof(TouchComboBox), new PropertyMetadata(null));

        // Public properties
        public int MaxVisibleItems
        {
            get { return (int)GetValue(MaxVisibleItemsProperty); }
            set { SetValue(MaxVisibleItemsProperty, value); }
        }

        public double MaxHeightInPixels
        {
            get { return (double)GetValue(MaxHeightInPixelsProperty); }
            set { SetValue(MaxHeightInPixelsProperty, value); }
        }

        public double ScrollAcceleration
        {
            get { return (double)GetValue(ScrollAccelerationProperty); }
            set { SetValue(ScrollAccelerationProperty, value); }
        }

        public double ScrollDeceleration
        {
            get { return (double)GetValue(ScrollDecelerationProperty); }
            set { SetValue(ScrollDecelerationProperty, value); }
        }

        public bool IsDropDownOpen
        {
            get { return (bool)GetValue(IsDropDownOpenProperty); }
            set { SetValue(IsDropDownOpenProperty, value); }
        }

        public double CalculatedMaxDropDownHeight
        {
            get { return (double)GetValue(CalculatedMaxDropDownHeightProperty); }
            set { SetValue(CalculatedMaxDropDownHeightProperty, value); }
        }

        // ComboBox properties
        public IEnumerable ItemsSource
        {
            get { return (IEnumerable)GetValue(ItemsSourceProperty); }
            set { SetValue(ItemsSourceProperty, value); }
        }

        public object SelectedItem
        {
            get { return (object)GetValue(SelectedItemProperty); }
            set { SetValue(SelectedItemProperty, value); }
        }

        public string DisplayMemberPath
        {
            get { return (string)GetValue(DisplayMemberPathProperty); }
            set { SetValue(DisplayMemberPathProperty, value); }
        }

        public string SelectedValuePath
        {
            get { return (string)GetValue(SelectedValuePathProperty); }
            set { SetValue(SelectedValuePathProperty, value); }
        }

        public object SelectedValue
        {
            get { return (object)GetValue(SelectedValueProperty); }
            set { SetValue(SelectedValueProperty, value); }
        }

        // Private fields for touch scrolling
        private Point _touchStartPoint;

        private bool _isDragging = false;
        private DispatcherTimer _scrollTimer;
        private double _scrollVelocity = 0;
        private ScrollViewer _scrollViewer;
        private ComboBoxItem _touchDownItem;

        public TouchComboBox()
        {
            InitializeComponent();
            this.DataContext = this;
            this.SizeChanged += TouchComboBox_SizeChanged;
        }

        private void TouchComboBox_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            CalculateMaxDropDownHeight();
        }

        private void InternalComboBox_DropDownOpened(object sender, EventArgs e)
        {
            // Find the ScrollViewer within the ComboBox's template
            _scrollViewer = FindVisualChild<ScrollViewer>(InternalComboBox);
            IsDropDownOpen = true;
        }

        private void InternalComboBox_DropDownClosed(object sender, EventArgs e)
        {
            _scrollViewer = null;
            IsDropDownOpen = false;
        }

        private void InternalComboBox_PreviewTouchDown(object sender, TouchEventArgs e)
        {
            _touchStartPoint = e.GetTouchPoint(this).Position;
            _isDragging = false;

            // Get the item that was touched
            _touchDownItem = FindVisualParent<ComboBoxItem>(e.OriginalSource as DependencyObject);

            // Stop any ongoing scrolling
            if (_scrollTimer != null)
            {
                _scrollTimer.Stop();
            }
        }

        private void InternalComboBox_PreviewTouchMove(object sender, TouchEventArgs e)
        {
            var currentPoint = e.GetTouchPoint(this).Position;
            var delta = currentPoint.Y - _touchStartPoint.Y;

            // Check if the user is dragging to prevent tapping from becoming a drag
            if (Math.Abs(delta) > 10) // A small threshold
            {
                _isDragging = true;

                if (_scrollViewer != null)
                {
                    // Calculate and apply immediate scroll based on finger movement
                    double newOffset = _scrollViewer.VerticalOffset - (delta * 0.5);
                    _scrollViewer.ScrollToVerticalOffset(newOffset);
                }
            }

            // Update the start point for the next move
            _touchStartPoint = currentPoint;
        }

        private void InternalComboBox_PreviewTouchUp(object sender, TouchEventArgs e)
        {
            if (_isDragging)
            {
                // Prevent selection after a drag action
                var touchUpItem = FindVisualParent<ComboBoxItem>(e.OriginalSource as DependencyObject);
                if (touchUpItem == _touchDownItem)
                {
                    // If the finger was lifted off the same item it started on,
                    // we can't tell if it was a drag, so we allow the ComboBox to handle it.
                    // Instead, we only prevent selection if the finger was moved to a new item
                    // or if it was a drag action in general. This is a heuristic approach.
                    // The standard ComboBox behavior is to not select on drag, so this is mainly for
                    // the tapping logic.
                    // The main goal is for touch-and-hold-drag to scroll, not select.
                }

                // Start the smooth deceleration scroll
                StartSmoothScroll();

                // Mark event as handled to prevent default ComboBox item selection
                e.Handled = true;
            }
        }

        private void InternalComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Check if we are in a dragging state. If so, don't allow selection.
            if (_isDragging)
            {
                // To prevent selection, we must handle the event.
                // We'll revert the selection back to the previous item.
                // This is a bit of a hack but necessary for this feature.
                // The ComboBox's SelectionChanged event fires before PreviewTouchUp,
                // so we can't fully prevent it there.
                e.Handled = true;
            }
        }

        private void TouchComboBox_PreviewTouchDown(object sender, TouchEventArgs e)
        {
            // The PreviewTouchDown on the UserControl catches the touch event for the whole control,
            // including the collapsed ComboBox area, allowing us to prevent touch events from bubbling.
            // This is crucial for handling the tap to open/select correctly.
            var touchPoint = e.GetTouchPoint(this).Position;
            var hitTestResult = VisualTreeHelper.HitTest(InternalComboBox, touchPoint);

            if (hitTestResult == null || hitTestResult.VisualHit is ComboBox)
            {
                // A tap on the main ComboBox area will open the dropdown
                InternalComboBox.IsDropDownOpen = !InternalComboBox.IsDropDownOpen;
                e.Handled = true;
            }
        }

        private void StartSmoothScroll()
        {
            if (_scrollViewer == null) return;

            // Use the last velocity to start the smooth scroll
            // This is a simplified approach, a real-world app might use a more complex physics model
            // based on the total delta and time of the drag.
            _scrollVelocity = -(_touchStartPoint.Y - Mouse.GetPosition(this).Y);

            _scrollTimer = new DispatcherTimer();
            _scrollTimer.Interval = TimeSpan.FromMilliseconds(16); // ~60fps
            _scrollTimer.Tick += SmoothScrollTick;
            _scrollTimer.Start();
        }

        private void SmoothScrollTick(object sender, EventArgs e)
        {
            if (_scrollViewer == null)
            {
                _scrollTimer.Stop();
                return;
            }

            // Apply deceleration
            _scrollVelocity -= _scrollVelocity > 0
                ? ScrollDeceleration
                : -ScrollDeceleration;

            // Apply velocity to the scroll viewer
            _scrollViewer.ScrollToVerticalOffset(_scrollViewer.VerticalOffset + _scrollVelocity);

            // Stop the timer when velocity is negligible
            if (Math.Abs(_scrollVelocity) < 0.5)
            {
                _scrollTimer.Stop();
                _scrollVelocity = 0;
                _isDragging = false; // Reset drag state
            }
        }

        private void CalculateMaxDropDownHeight()
        {
            if (!double.IsNaN(MaxHeightInPixels))
            {
                CalculatedMaxDropDownHeight = MaxHeightInPixels;
            }
            else
            {
                var item = InternalComboBox.ItemContainerGenerator.ContainerFromIndex(0) as ComboBoxItem;
                if (item != null)
                {
                    double itemHeight = item.ActualHeight;
                    CalculatedMaxDropDownHeight = itemHeight * MaxVisibleItems;
                }
                else
                {
                    // Fallback if no items are loaded yet
                    CalculatedMaxDropDownHeight = 200;
                }
            }
        }

        // Helper method to find a visual child of a specific type
        private static T FindVisualChild<T>(DependencyObject parent) where T : DependencyObject
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);
                if (child is T typedChild)
                {
                    return typedChild;
                }
                else
                {
                    T result = FindVisualChild<T>(child);
                    if (result != null)
                    {
                        return result;
                    }
                }
            }
            return null;
        }

        // Helper method to find a visual parent of a specific type
        private static T FindVisualParent<T>(DependencyObject child) where T : DependencyObject
        {
            var parent = VisualTreeHelper.GetParent(child);
            while (parent != null && !(parent is T))
            {
                parent = VisualTreeHelper.GetParent(parent);
            }
            return parent as T;
        }
    }
}